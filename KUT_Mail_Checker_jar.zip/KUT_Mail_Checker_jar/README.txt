Enter your credentials to start using the script.

Note: Also as it's seen from the source code , your credentials stay local and isn't shared with any third party software or person.